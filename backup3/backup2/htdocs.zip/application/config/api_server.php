<?php defined('BASEPATH') OR exit('No direct script access allowed');


$config['api_link'] = 'http://viplikeviet.net/API'; 

$config['key'] = 'dev';  //Key lấy từ hệ thống
