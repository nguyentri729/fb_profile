<?php defined('BASEPATH') OR exit('No direct script access allowed');


$config['client_id'] = '3f9a53bd5ebb2fa'; 
